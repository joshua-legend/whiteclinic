import KMS_CCheckbox from './KMS_CCheckbox';

const meta = {
  title: 'components/KMS_CCheckbox',
  component: KMS_CCheckbox,
  argTypes: {},
};

export default meta;
export const Primary = {
  args: {},
};
