import KMS_CInfoInput from './KMS_CInput';

const meta = {
  title: 'components/KMS_CInfoInput',
  component: KMS_CInfoInput,
  argTypes: {},
};

export default meta;
export const Primary = {
  args: {},
};
