// src/components/inputFrame/inputs.tsx

import { KMS_CButton } from './KMS_CButton';

const meta = {
  title: 'components/KMS_CButton',
  component: KMS_CButton,
  argTypes: {},
};

export default meta;
export const Primary = {
  args:{
    type:"취소"
  },
};
