import KMS_CDropdown from './KMS_CDropdown';

const meta = {
  title: 'components/KMS_CDropdown',
  component: KMS_CDropdown,
  argTypes: {},
};

export default meta;
export const Primary = {
  args:{
    type:"수당률"
  },
};
